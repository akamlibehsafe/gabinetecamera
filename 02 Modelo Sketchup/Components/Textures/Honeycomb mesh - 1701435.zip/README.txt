Honeycomb mesh by valba on Thingiverse: https://www.thingiverse.com/thing:1701435

Summary:
Honeycomb mesh used in Cool PCB Enclosure.It is an optimized version of Openscad hex grid generatorNEW VERSION is available at this project:Parametric Honeycomb Mesh (with chamfered edges) 